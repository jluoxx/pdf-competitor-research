import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=path.dirname(new URL(import.meta.url).pathname).replace(/^\/([A-Za-z]:)/,'$1');
const base=decodeURIComponent(root);
const modules=path.resolve("D:\\python daima\\outputs\\competitor_apk_analysis_20261109\\toolchain\\node_modules");
const {Client}=await import(pathToFileURL(path.join(modules,'@modelcontextprotocol/client/dist/index.mjs')));
const {StdioClientTransport}=await import(pathToFileURL(path.join(modules,'@modelcontextprotocol/client/dist/stdio.mjs')));
const rea=path.join(modules,'rea-agents/scripts/rea.mjs');
const transport=new StdioClientTransport({command:process.execPath,args:[rea,'--mcp'],env:{...process.env,REA_JADX_MCP_JAR:path.resolve("D:\\python daima\\outputs\\competitor_apk_analysis_20261109\\deep_research\\toolchain\\jadx-headless-mcp-0.7.1-all.jar"),REA_JADX_HEAP_MIB:'3072',REA_JADX_ACTIVE_PROCESSOR_COUNT:'3',REA_JADX_OPERATION_TIMEOUT_MS:'300000'},stderr:'pipe'});
transport.stderr?.on('data',b=>fs.appendFileSync(path.join(base,'rea_server_stderr.log'),b));
const client=new Client({name:'competitor-research',version:'1.0.0'});
await client.connect(transport);
const listing=await client.listTools();
fs.writeFileSync(path.join(base,'sources/rea_tools.json'),JSON.stringify(listing,null,2));
console.log('READY',listing.tools.length);
const done=new Set();
while(true){
 if(fs.existsSync(path.join(base,'rea_stop')))break;
 const queue=JSON.parse(fs.readFileSync(path.join(base,'rea_queue.json'),'utf8'));
 for(const job of queue){
  if(done.has(job.package+job.id))continue;
  const dest=path.join(base,'raw',job.package,'rea');fs.mkdirSync(dest,{recursive:true});
  const file=path.join(dest,job.id+'.json');
  if(fs.existsSync(file)){done.add(job.package+job.id);continue;}
  const start=new Date().toISOString();console.log('START',job.id,job.tool);
  try{
   const result=await client.callTool({name:job.tool,arguments:job.args},undefined,{timeout:360000});
   fs.writeFileSync(file,JSON.stringify({job,start,end:new Date().toISOString(),result},null,2));console.log('DONE',job.id,'error',!!result.isError);
  }catch(e){fs.writeFileSync(file,JSON.stringify({job,start,end:new Date().toISOString(),exception:String(e)},null,2));console.log('FAIL',job.id,String(e));}
  done.add(job.package+job.id);
 }
 break;
}
await client.close();
