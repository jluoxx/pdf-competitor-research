from pathlib import Path
import urllib.request,json,datetime,base64
P=Path(__file__).parent;B=P.parent
opener=urllib.request.build_opener(urllib.request.ProxyHandler({'https':'http://127.0.0.1:7890'}));audit=[]
for kind in ['wb','ad']:
 old=json.loads((B/f'network_probe/{kind}_probe.json').read_text(encoding='utf-8'));row={'url':old['url'],'method':'POST','request':old['request'],'identifier_kind':'synthetic_same_as_previous','time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(row['url'],data=json.dumps(row['request']).encode(),headers={'Content-Type':'application/json'},method='POST')
  with opener.open(req,timeout=20) as r:body=r.read().decode('utf-8');row.update({'status':r.status,'body':body,'content_type':r.headers.get('Content-Type')})
  parsed=json.loads(body);row['code']=parsed.get('code')
  if kind=='wb':
   cfg=parsed['data']['ecceno'];(P/'refreshed_business_config.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
   oldcfg=json.loads((B/'online_business_config.json').read_text(encoding='utf-8'));row['changed_keys']=[k for k in set(cfg)|set(oldcfg) if cfg.get(k)!=oldcfg.get(k)];row['keys']=len(cfg)
   sc=json.loads(base64.b64decode(cfg['hvxlh']));(P/'refreshed_scenes.json').write_text(json.dumps(sc,ensure_ascii=False,indent=2),encoding='utf-8')
   row['scene_config_unchanged']=sc==json.loads((B/'online_nested_decoded.json').read_text(encoding='utf-8'))['hvxlh']
  else:
   ads=json.loads(base64.b64decode(parsed['data']));(P/'refreshed_ad_config.json').write_text(json.dumps(ads,ensure_ascii=False,indent=2),encoding='utf-8');row['space_count']=len(ads['spaces']);row['ad_config_unchanged']=ads==json.loads((B/'online_ad_config_decoded.json').read_text(encoding='utf-8'))
 except Exception as e:row['error']=str(e)
 (P/(kind+'_refresh_probe.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8');audit.append({k:v for k,v in row.items() if k not in ['body','request']})
(P/'refresh_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(audit,ensure_ascii=False,indent=2))
