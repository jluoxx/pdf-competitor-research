from pathlib import Path
import json,re,ast,hashlib
P=Path(__file__).parent;B=P.parent
cfg=json.loads((B/'online_business_config.json').read_text(encoding='utf-8'));nested=json.loads((B/'online_nested_decoded.json').read_text(encoding='utf-8'));sc=nested['hvxlh']
summary={'config_snapshot':'2026-11-11T14:35:39+08:00','scene_count':len(sc),'org_negative':[k for k,v in sc.items() if v['org_dly']<0],'org_negative_but_cd_nonnegative':[k for k,v in sc.items() if v['org_dly']<0 and v['cd']>=0],'cd_negative':[k for k,v in sc.items() if v['cd']<0],'org_nonnegative':[k for k,v in sc.items() if v['org_dly']>=0], 'not_returned_keys':{k:k in cfg for k in ['ccsulso','bojt','gpphk']}}
# Independently decode the condition-map key in q77$a.b using the exact method payload.
S=Path(r'D:\python daima\outputs\pdf_competitor_analysis_20261110\sources\com.alldocument.fileviewer.tools\business_bytecode.txt')
active=False;method=False;lines=[]
with S.open(encoding='utf-8') as f:
 for l in f:
  if l.startswith('CLASS '):active=l.strip()=='CLASS Lq77$a;'
  if active and l.startswith('METHOD '):method=l.strip()=='METHOD b ()Z'
  if active and method:lines.append(l)
payload={}
for l in lines:
 m=re.match(r'([0-9a-f]+): fill-array-data-payload (.+?) \|',l)
 if m:payload[int(m[1],16)]=ast.literal_eval(m[2])
key=chr(((-85)&255)^payload[0x108+0x134*2][0]);assert key=='3'
summary['q77_a_b_fallback_key']={'decoded':key,'bytecode_offset':'00010e','cipher_first_byte':171,'xor_key_first_byte':payload[0x370][0]}
audit=[]
for engine in ['rea','craft']:
 for j in json.loads((P/(engine+'_queue.json')).read_text(encoding='utf-8')):
  raw=P/'raw/com.alldocument.fileviewer.tools'/engine/(j['id']+'.json');rec={'engine':engine,'job':j,'status':'not_completed'}
  if raw.exists():
   d=json.loads(raw.read_text(encoding='utf-8'));rec.update({'raw':str(raw.relative_to(P)), 'status':'error' if d.get('exception') or d.get('result',{}).get('isError') or d.get('returncode',0)!=0 else 'usable'})
   if d.get('exception'):rec['exception']=d['exception']
   if engine=='rea':
    n=d.get('result',{}).get('structuredContent',{}).get('normalized_result',{});s=n.get('source',{});text=s.get('text','') if isinstance(s,dict) else str(s)
    if text:(P/(j['id']+'.java.txt')).write_text(text,encoding='utf-8');rec['representation']=n.get('representation')
   else:
    outf=raw.with_name(raw.stem+'.stdout.json')
    if outf.exists():
     d=json.loads(outf.read_text(encoding='utf-8'));r=d.get('result',{});rec['subject']=d.get('subject');rec['status']='usable' if r and rec['status']=='usable' else 'error'
     if j['tool']=='android-method-show':(P/(j['id']+'.craft.txt')).write_text('\n'.join(x['offset']+': '+x['text'] for x in r.get('instructions',[])),encoding='utf-8')
  audit.append(rec)
(P/'tool_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
summary['tool_counts']={e:{s:sum(x['engine']==e and x['status']==s for x in audit) for s in ['usable','error','not_completed']} for e in ['rea','craft']}
(P/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summary,ensure_ascii=False,indent=2))
