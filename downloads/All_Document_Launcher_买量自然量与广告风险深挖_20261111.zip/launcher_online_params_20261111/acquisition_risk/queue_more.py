from pathlib import Path
import json
P=Path(__file__).parent;q=json.loads((P/'rea_queue.json').read_text(encoding='utf-8'));apk=q[0]['args']['path']
for i,(cls,m) in enumerate([('q77$a','b'),('hle','k'),('qx6','m'),('uod','g'),('b87','r')]):
 q.append({'id':f'follow_{i:02d}','package':'com.alldocument.fileviewer.tools','tool':'inspect_android_method','args':{'path':apk,'class_name':cls,'method_name':m}})
(P/'rea_queue.json').write_text(json.dumps(q),encoding='utf-8')
