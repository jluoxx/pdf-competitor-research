import json
from pathlib import Path
P=Path(__file__).parent;B=P.parent
PKG='com.alldocument.fileviewer.tools';APK=str(Path(r'C:\Users\asus\Desktop\竞品apk\2026-11-10竞品apk')/PKG/'base.apk')
(P/'sources').mkdir(exist_ok=True)
jobs=[]
for i,(cls,m) in enumerate([('q77$a','b'),('bq6','d'),('q77$e$a','b'),('eg','s'),('gmc','q')]):
 jobs.append({'id':f'acq_{i:02d}','package':PKG,'tool':'inspect_android_method','args':{'path':APK,'class_name':cls,'method_name':m}})
(P/'rea_queue.json').write_text(json.dumps(jobs),encoding='utf-8')
script=(B/'rea_worker.mjs').read_text(encoding='utf-8').replace("jadx.operation_timeout_ms", "jadx.operation_timeout_ms").replace("REA_JADX_OPERATION_TIMEOUT_MS:'300000'","REA_JADX_OPERATION_TIMEOUT_MS:'70000'").replace('timeout:360000','timeout:90000')
(P/'rea_worker.mjs').write_text(script,encoding='utf-8')
craft=[]
for i,cls in enumerate(['q77$a','bq6','q77$e$a']):
 craft.append({'id':f'acq_{i:02d}','package':PKG,'tool':'android-class-show','args':{'path':APK,'class_name':cls,'format':'smali'}})
(P/'craft_queue.json').write_text(json.dumps(craft),encoding='utf-8')
script=(B/'craft_worker.py').read_text(encoding='utf-8').replace("str(P/'craft_project.cany')","str(P.parent/'craft_project.cany')").replace('timeout=180','timeout=100')
(P/'craft_worker.py').write_text(script,encoding='utf-8')
tools=json.loads((B/'sources/rea_tools.json').read_text(encoding='utf-8'))['tools']
for x in tools:
 if x['name']=='inspect_android_method':(P/'sources/method_schema.json').write_text(json.dumps(x,indent=2),encoding='utf-8')
