from pathlib import Path
import json
P=Path(__file__).parent
q=json.loads((P/'craft_queue.json').read_text(encoding='utf-8-sig'));apk=q[0]['args']['path']
for i,(cls,m) in enumerate([('q77$a','b'),('bq6','d'),('qx6','m'),('uod','g')]):
 q.append({'id':f'method_{i:02d}','package':'com.alldocument.fileviewer.tools','tool':'android-method-show','args':{'path':apk,'class_name':cls,'method_name':m,'limit':5000}})
(P/'craft_queue.json').write_text(json.dumps(q),encoding='utf-8')
for f in (P/'raw/com.alldocument.fileviewer.tools/rea').glob('*.json'):
 d=json.loads(f.read_text(encoding='utf-8'));s=d.get('result',{}).get('structuredContent',{}).get('normalized_result',{}).get('source',{});t=s.get('text','') if isinstance(s,dict) else str(s)
 if t:(P/(f.stem+'.java.txt')).write_text(t,encoding='utf-8')
print('method sources extracted')
