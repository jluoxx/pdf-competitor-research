from pathlib import Path
import json,datetime,urllib.request,re
P=Path(__file__).parent/'policy';P.mkdir(exist_ok=True)
pages={'ads':'https://support.google.com/googleplay/android-developer/answer/9857753?hl=en','deceptive':'https://support.google.com/googleplay/android-developer/answer/9888077?hl=en'}
import socket
with socket.create_connection(('127.0.0.1',7890),timeout=2):pass
opener=urllib.request.build_opener(urllib.request.ProxyHandler({'https':'http://127.0.0.1:7890','http':'http://127.0.0.1:7890'}))
from html import unescape
rows=[]
for key,url in pages.items():
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with opener.open(req,timeout=20) as r:html=r.read().decode('utf-8');status=r.status;final=r.url
  (P/(key+'.html')).write_text(html,encoding='utf-8')
  clean=re.sub(r'<(script|style|nav|footer|header)\b[^>]*>.*?</\1>','',html,flags=re.S|re.I)
  text=unescape(re.sub(r'<[^>]+>','\n',clean));text=re.sub(r'\n\s*\n','\n',text);(P/(key+'.txt')).write_text(text,encoding='utf-8')
  title=re.search(r'<title[^>]*>(.*?)</title>',html,re.S|re.I)
  rows.append({'key':key,'url':url,'final_url':final,'status':status,'title':unescape(title[1]) if title else '', 'chars':len(text),'time':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 except Exception as e:rows.append({'key':key,'url':url,'error':str(e)})
(P/'fetch_audit.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(rows,ensure_ascii=False))
