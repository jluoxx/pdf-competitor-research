from pathlib import Path
import json,csv,re,zipfile,hashlib,datetime
P=Path(__file__).parent;B=P.parent
summary=json.loads((P/'summary.json').read_text(encoding='utf-8'))
cfg=json.loads((P/'refreshed_business_config.json').read_text(encoding='utf-8'))
sc=json.loads((P/'refreshed_scenes.json').read_text(encoding='utf-8'))
oldrows=list(csv.DictReader((B/'广告场景频控26项.csv').open(encoding='utf-8-sig')))
rows=[]
for old in oldrows:
 k=old['场景ID'];v=sc[k]
 rows.append({'场景ID':k,'触发线索':old['触发线索'],**v,'广告路由':old['本次广告路由'],'org分组结果':'cd<0直接禁用' if v['cd']<0 else ('org_dly<0拦截' if v['org_dly']<0 else '这一层未因org分组拦截'),'SAFE分组结果':'cd<0直接禁用' if v['cd']<0 else ('首日状态下dly<0拦截' if v['dly']<0 else '仍需通过时间、缓存及其他限制')})
with (B/'人群分层场景26项.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
report='''# All Document - File Viewer：买量／自然用户与广告风险专项

包名：`com.alldocument.fileviewer.tools`；versionName=1.0 / versionCode=11。base SHA-256：`7eda322286a3ecdaf7ab054db02b4e2d66a05c5fb5d329e2f9d08d0d7178376d`。

## 结论先看

**有在线参数控制自然与非自然来源的广告差异，而且不是单纯的自然量开关。** 已还原链路：归因融合结果 → 来源与环境风险检查 → 内部org分组 → 逐场景广告限制。自然来源会进入受限分组；非自然来源也必须满足相关检查，才能脱离该组。因此“自然用户少广告，符合条件的买量用户进入更多广告流程”有代码及在线值支撑；“所有买量用户都展示、自然用户完全无广告”不成立。

**存在明显值得核查的广告风险组合**：应用抽屉点图标前的插屏流程、使用第三方应用后回到桌面的插屏调用，以及按同一风险分组改变部分图标和设置入口的隐藏行为。前两项属于优先核查的打断式广告风险；后一组合具有差异展示能力，但不能仅凭静态代码证明其目的就是躲避审核。

本轮15:28（北京时间）重新请求业务与广告配置：均HTTP200、业务code200；仍为44项业务键、26场景、29路由记录。26场景规则和29路由与14:35快照一致；业务另有11个尚未确定含义的键发生变化，不能据此推断人群AB策略。沿用同一合成Android ID和安装时间，未伪造真实买量回调，未请求广告内容或上传曝光。

## 1. 控制买量／自然用户的究竟是什么

|控制层|参数／状态|本次在线值|已证实的用途|
|---|---|---|---|
|场景配置总入口|`hvxlh`|Base64 JSON，26场景|解码后给各场景判定器设置规则|
|受限分组控制|各scene的`org_dly`|21个场景=-1|内部org分组成立时，负数直接拦截该场景|
|风险条件入口|`liefm`解出`limit_condition`|`1,2,3`|启用ADB、时间及归因来源相关条件|
|投放活动匹配|`ccsulso`（`g28.o0`）|本次44项未返回|非自然来源可按campaign关键词列表进一步筛选；缺失时此匹配层按空列表处理|
|媒体名称归一化|`bojt`（`g28.R1`）|本次未返回|Base64后可更新媒体别名映射；不是已证实的广告开关|
|图标隐藏|`eeffer` / hide_icon|1|结合内部org分组、本地item规则判断|
|设置入口隐藏|`fzgtb` / hide_settings|1|org分组成立时不执行该隐藏判断；否则配置=1时隐藏判断成立|

`org_dly=-1`不是“等负一秒”，也不是仅首开延迟：在对应状态成立时，基本判定器直接返回`org disabled`。同一个字段为正数时，时间判定器才按秒换算，与首启时间比较。

**计数口径：**26场景中21个org_dly为负；其中4个已经被cd<0对所有分组禁用。因此另有17个cd非负场景会受到org分组额外限制。17个里仍有缺广告路由或首日dly禁用的条目，不能把17直接当作实际可曝光点位数。

证据：[新响应](acquisition_risk/wb_refresh_probe.json)、[新业务配置](acquisition_risk/refreshed_business_config.json)、[26场景分组表](人群分层场景26项.csv)、[基本判定atb.b](atb.bytecode.decoded.txt)、[时间判定zsb.b](zsb.bytecode.decoded.txt)、[字段映射](alias_map.json)。

## 2. 归因是怎样传到广告判断的

### 2.1 自然与非自然来源判定

`jh0`中存在Install Referrer和第三方归因融合逻辑；融合模型`el5`包含organic、network、campaign等字段。`el5.i()`对organic字符串与`Organic`进行忽略大小写的相等比较。

`q77.e`合并归因结果流`jh0.J()`和在线配置流`scd.e()`，随后`q77$e$a.b`把网络、campaign以及解码后的限制参数交给`b87`。来源检测器`bq6`监听融合归因结果，编号为3。

来源检测器的关键分支已被REA和字节码交叉核对：

```text
没有融合归因结果 → UNKNOWN
organic == Organic → RSK，说明为illegal-source
非自然来源：
    ccsulso为空／缺失／解析失败 → 空关键词表 → SAFE
    关键词表非空且campaign包含任一关键词 → SAFE
    否则 → RSK，说明为illegal-camp
```

这里的`RSK`是该应用SDK内部枚举，不代表自然用户真的存在欺诈或安全风险。`ccsulso`筛选的是campaign字符串，不能误写成网络平台白名单。`Non-Organic`也只是非自然归因标签，不独立证明发生过付费投放。

证据：[REA读取bq6.d](acquisition_risk/acq_01.java.txt)、[bq6解码字节码](acquisition_risk/bq6.txt)、[Craft交叉读取](acquisition_risk/method_01.craft.txt)、[融合模型](acquisition_risk/el5.txt)、[归因融合](acquisition_risk/jh0.txt)、[配置与归因连接](acquisition_risk/q77$e$a.txt)。

### 2.2 内部org比自然归因范围更大

`q77.i`确实把`q77$a`作为`af1`回调注入广告控制器。`q77$a.b()`是场景判定器读取的org状态来源，其逻辑可概括为：

```text
details为空 → true
没有任何启用的条件，且有编号3的来源结果 → 来源状态 != SAFE
其余情况 → 汇总风险状态 != SAFE
```

所以未获得结果、结果未知、自然来源或启用的其他条件未通过，都可能使org=true；不能把它直接等同于归因平台的isOrganic。

`b87.r`只汇总已启用的检查：有RSK则汇总为RSK；已启用检查全部SAFE且非空才为SAFE；其他情况为UNKNOWN。本次启用集合为1/2/3，故非自然来源也可能因为ADB或时间条件被划进受限组。

|条件|证据与边界|
|---|---|
|1：ADB|`ve$a$a.emit`读取adb_enabled；值=1写RSK，否则SAFE；本次启用|
|2：系统时间|监听auto_time、手动设置时间／时区，结合时间变化条件处理；本次启用，但没有测任何设备是否命中|
|3：来源／campaign|自然来源RSK，非自然来源按上述匹配规则；本次启用|
|4：包安装检查|包内有PackageManager及包变化监听；本次未启用。虽然limit_package含org.wireshark.android，不能说当前正在检查该包|
|84：测试环境检查|包内t15类包含Firebase Test Lab相关读取，但本链路的b87$a初始注册列表只有1/2/3/4，且当前启用集合也没有84；不认定当前已检测审核／Test Lab环境|

证据：[org回调](acquisition_risk/q77$a.txt)、[回调注入](acquisition_risk/q77.txt)、[Craft方法原始指令](acquisition_risk/method_00.craft.txt)、[枚举SAFE/RSK/UNKNOWN](acquisition_risk/p0b.txt)、[汇总规则](acquisition_risk/b87.txt)、[ADB检查](acquisition_risk/ve$a$a.txt)、[注册列表](acquisition_risk/b87$a.txt)、[条件打包解码](online_limit_condition_decoded.json)。

### 2.3 dly是另一条时间／首日限制，不是买量判定

`q77$a.c()`读取`first_time_niuma`，`gu.a()`首次写当前时间。`q77$a.e()`在该时间缺失／异常小，或首启日期与当天DAY_OF_YEAR相同时返回true。基本判定器在此状态下检查dly<0；时间判定器把正dly乘1000，与距首启的时长比较。

因此`23000045.dly=1`是这层首启后1秒门槛，不能解释成安装一天后才展示，也不能用它证明规避审核。`44000036.dly=-1`则还受首日状态拦截。

证据：[首启写入](acquisition_risk/gu.txt)、[首日判断](acquisition_risk/q77$a.txt)、[字段解析](m050_bq7$b$a.a.java.txt)。

## 3. 最值得关注的在线广告配置

|场景／行为|本次参数|实际追到的代码动作|判断|
|---|---|---|---|
|23000045：应用抽屉图标点击|cd=60、dly=1、org_dly=-1；有plaque路由|qx6.m在若干直接启动例外以外调用hle.k，启动目标应用动作通过回调传入；hle$e可进入插屏展示接口|高风险候选：用户要打开目标应用，却先经过广告流程|
|23000046：第三方应用后回到桌面|cd=300、dly=0、org_dly=-1；有plaque路由|LawnchairLauncher.onResume→uod.g；符合桌面状态及记录包条件时调用ija.b→广告展示接口|高风险候选：回桌面时出现非预期插屏|
|23000035／36：启动／引导|cd=0、dly=0、org_dly=0|有启动／引导相关调用与广告路由|这层对org组也未禁用；是否发生加载页前广告、连续插屏需真机证据|
|eeffer=1、fzgtb=1|部分图标／设置入口隐藏开关|px5.j／l复用q77.m的分组；org=true时保留设置入口，org=false且开关为1时隐藏判断成立|高关注：人群与环境状态能改变可见入口；用户知情、可恢复性未知|
|wfazza=3600|重设首选桌面相关间隔1小时|接收器还有默认桌面、前台等条件|需核查：不等于每小时强制夺回桌面；若未经同意改变设置才涉及相应政策问题|
|wvkns解码{}；全部场景次数上限字段0|该层无正数全局／场景次数上限|仍受cd、org、首日、路由和广告就绪限制|频控较宽松线索；没有每日正数上限本身不能直接认定违规|

**23000045触发链：**点击应用抽屉图标 → 部分系统／特殊项走直接启动例外 → 普通分支`hle.k(...23000045, callback)` → 就绪时插屏展示接口 → 流程结果回调关联目标应用启动。这里既有展示分支也有失败／无缓存的回退，不能写成每次点击都强制看广告。

**23000046触发链：**记录前次启动包 → Launcher.onResume → 排除自身及部分系统包／自身功能 → 确认处在主桌面且不是负一屏 → 消费记录 → 23000046广告调用。它是在桌面恢复时触发，不能据此写成正在第三方App前台时覆盖其界面。

证据：[图标点击](acquisition_risk/qx6.txt)、[目标动作回调](acquisition_risk/qx6$a.txt)、[广告流程](acquisition_risk/hle.txt)、[插屏展示分支](acquisition_risk/hle$e.txt)、[桌面onResume](acquisition_risk/app.lawnchair.LawnchairLauncher.txt)、[第三方包与桌面分支](acquisition_risk/uod.txt)、[展示调用](acquisition_risk/ija.txt)、[图标隐藏判断](m064_px5.j.java.txt)、[设置隐藏判断](m066_px5.l.java.txt)、[29路由新响应](acquisition_risk/refreshed_ad_config.json)。

## 4. 哪些可能违规，哪些只能说可疑

本轮已实际读取Google Play官方政策，保存HTML、正文和抓取时间。以下是根据政策与代码作出的风险评估，不是Google的处罚结论。

1. **打断用户打开应用／回到桌面的插屏：高风险。** 官方禁止在用户选择其他操作时突然出现全屏插屏，以及干扰其他应用和设备操作的广告。23000045与23000046应优先验证触发时机、广告是否全屏、是否明确可关闭、目标动作是否被阻断。来源：[Ads](https://support.google.com/googleplay/android-developer/answer/9857753?hl=en)。
2. **按环境和归因改变可见入口、压制广告：具有规避审核的可疑组合，但动机未证实。** 在线条件能把自然来源、ADB等状态纳入受限分组，且同一组影响广告与设置／图标隐藏。官方禁止审核规避、未披露的核心功能差异和远程激活的隐蔽功能；但常规反作弊或广告分层本身不能直接等同于审核规避。仍缺商店完整披露核对、实际人群UI对照、审核环境差异运行证据。来源：[Deceptive Behavior，尤其Behavior Transparency](https://support.google.com/googleplay/android-developer/answer/17006354?hl=en)。
3. **隐藏设置／图标及重设桌面：需核查知情同意与恢复方式。** 官方要求用户知情同意地改变相关设备设置，并可方便恢复；本次只证明控制与判断链，未观察到真实设备设置变化或用户协议流程。来源同上。

Launcher桌面本身可以是该App的界面，**不能因为广告出现在桌面就自动判成应用外广告**。重点是是否在用户没有预期的操作点打断正常使用、干扰其他App或系统操作，以及是否透明披露。

以下尚无足够证据，不能认定：自动点击广告／伪造曝光、强制跳转商店、假关闭按钮、无法关闭超过15秒、锁屏广告已启用、后台覆盖其他App、检测到审核身份后藏广告。不存在这些结论不代表功能不存在，而是本轮未观察到足够证据。

政策原文证据：[Ads正文](acquisition_risk/policy/ads.txt)、[Deceptive Behavior正文](acquisition_risk/policy/deceptive.txt)、[抓取记录](acquisition_risk/policy/fetch_audit.json)。

## 5. 证据覆盖与未执行项

|问题|本轮状态|边界|
|---|---|---|
|是否有自然／非自然来源分层|已确认代码消费链及线上场景值|不是两台真实用户设备的对照实验|
|当前场景参数是否仍一致|15:28重新请求两套配置，已验证|合成标识、同一请求条件；此次网络经本机已有代理，未改变系统代理设置|
|自然用户是否完全无广告|不能支持；部分启动／引导场景org_dly=0|实际能否显示仍受其他层约束|
|买量用户是否必定开放所有广告|不能支持；风险检查、首日、场景禁用及路由仍生效|未知真实设备归因及检查结果|
|广告违规是否已经坐实|尚未|没有真机截图、录像、关闭交互或impression回调|
|本轮工具|REA有效4项；Craft有效7项，含类与实际方法指令|REA另外4项超时、2项未完成；错误已保留，未冒充成功|

REA成功结果包含Java与smali回退，表示形式按原始结果保留；`acq_02.java.txt`扩展名不保证内容一定为Java。字节码解码用于定位，分支与返回值以原指令交叉判断；线性解码遇寄存器跨分支复用时，个别调试字符串可能不完整，不用其乱码部分支撑结论。

下一阶段若做运行验证，最有价值的是在明确设备及操作范围后采集两类已真实归因用户的当前配置、风险汇总结果、桌面入口截图，连续验证应用图标点击及从第三方App返回的广告行为。ADB本身就在启用条件内，因此测试连接状态会影响分组，不能把调试环境看不到广告直接当成生产人群也没有。本轮未修改设备、未篡改归因、未尝试绕过检查。

[刷新对比记录](acquisition_risk/refresh_audit.json) · [分组计数和关键字节独立核对](acquisition_risk/summary.json) · [本轮工具审计](acquisition_risk/tool_audit.json) · [上一轮完整参数报告](在线参数深挖报告.md)。
'''
(B/'买量自然量与广告风险专项.md').write_text(report,encoding='utf-8')
# Keep the original report consistent with the newly closed consumer chain.
main=B/'在线参数深挖报告.md';s=main.read_text(encoding='utf-8')
notice='> 续查更新：已闭环自然／非自然来源与org广告分组，并于15:28刷新接口；见[买量自然量与广告风险专项](买量自然量与广告风险专项.md)。下文原值仍保留14:35取样时点。\n\n'
if notice not in s:s=s.replace('\n\n包名：','\n\n'+notice+'包名：',1)
s=s.replace('newer/org属于运行状态判断，不能仅凭名字把所有用户划为新老用户或自然量；当前取样没有设备归因/状态，因此不判断谁一定命中。','续查已闭环：newer来自首启日期状态，org来自风险结果回调，涵盖自然来源、风险条件未通过及未知等情况，不能直接等同自然用户。详见买量自然量与广告风险专项；仍无真实设备分组结果。')
main.write_text(s,encoding='utf-8')
# Verify report links and CSV contents before packaging.
missing=[]
for md in [main,B/'买量自然量与广告风险专项.md']:
 for link in re.findall(r'\]\(([^)]+)\)',md.read_text(encoding='utf-8')):
  if not re.match(r'https?://',link) and not (md.parent/link).exists():missing.append(link)
assert not missing,missing
assert len(rows)==26 and sum(v['org_dly']<0 for v in sc.values())==21
apk=Path(r'C:\Users\asus\Desktop\竞品apk\2026-11-10竞品apk\com.alldocument.fileviewer.tools\base.apk')
sha=hashlib.sha256(apk.read_bytes()).hexdigest();assert sha=='7eda322286a3ecdaf7ab054db02b4e2d66a05c5fb5d329e2f9d08d0d7178376d'
check={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_links_missing':missing,'csv_rows':len(rows),'sha256':sha,'policy_http200':all(x.get('status')==200 for x in json.loads((P/'policy/fetch_audit.json').read_text(encoding='utf-8'))),'rea_craft':summary['tool_counts']}
(P/'delivery_validation.json').write_text(json.dumps(check,ensure_ascii=False,indent=2),encoding='utf-8')
zip_path=B.parent/'All_Document_Launcher_买量自然量与广告风险深挖_20261111.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for f in B.rglob('*'):
  if f.is_file() and f.suffix not in ['.cany','.log'] and '__pycache__' not in f.parts:z.write(f,Path(B.name)/f.relative_to(B))
with zipfile.ZipFile(zip_path) as z:assert z.testzip() is None
print(json.dumps({'report':str(B/'买量自然量与广告风险专项.md'),'zip':str(zip_path),'zip_bytes':zip_path.stat().st_size,'validation':check},ensure_ascii=False,indent=2))
