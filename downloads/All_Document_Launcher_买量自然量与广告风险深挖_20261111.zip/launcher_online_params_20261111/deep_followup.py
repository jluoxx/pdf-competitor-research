import re,json,ast,sys
from pathlib import Path
P=Path(__file__).parent
S=Path(r'D:\python daima\outputs\pdf_competitor_analysis_20261110\sources\com.alldocument.fileviewer.tools')
D=P/'acquisition_risk';D.mkdir(exist_ok=True)
def decode(text):
 if text.count('\nMETHOD ')>1:
  parts=re.split(r'(?=\nMETHOD )',text)
  return ''.join(decode(part)+'\n' for part in parts)
 out=[];regs={};payload={}
 for l in text.splitlines():
  m=re.match(r'([0-9a-f]+): fill-array-data-payload (.+?) \|',l)
  if m:
   try:payload[int(m[1],16)]=bytearray(ast.literal_eval(m[2]))
   except Exception:pass
 for l in text.splitlines():
  if l.startswith('METHOD '):regs={}
  out.append(l)
  m=re.match(r'([0-9a-f]+): ([^ ]+) (.*)',l)
  if not m:continue
  off=int(m[1],16);op=m[2];args=m[3].split(', ')
  try:
   if op.startswith('const') and not op.startswith(('const-string','const-class','const-wide')):regs[args[0]]=int(args[1])
   elif op=='new-array' and args[-1]=='[B':regs[args[0]]=bytearray(regs[args[1]])
   elif op=='fill-array-data':regs[args[0]]=payload[off+int(args[1].removesuffix('h'),16)*2][:len(regs[args[0]])].copy()
   elif op=='aput-byte':regs[args[1]][regs[args[2]]]=regs[args[0]]&255
   elif op.startswith('move') and not op.startswith(('move-result','move-exception')):regs[args[0]]=regs[args[1]]
   elif op=='invoke-static' and 'Lj1d;->a(' in l:
    a,b=regs[args[0]],regs[args[1]];out.append('    DECODED '+json.dumps(bytes(c^b[i%len(b)] for i,c in enumerate(a)).decode('utf-8'),ensure_ascii=False))
  except Exception:pass
 return '\n'.join(l for l in out if 'fill-array-data-payload ' not in l)
if sys.argv[1]=='strings':
 pat=re.compile(sys.argv[2],re.I)
 for r in json.loads((S/'decoded_strings.json').read_text(encoding='utf-8')):
  if any(pat.search(s) for s in r['decoded']):print(json.dumps(r,ensure_ascii=False))
elif sys.argv[1]=='classes':
 want={'L'+x.replace('.','/')+';' for x in sys.argv[2:]};c='';lines=[]
 def flush():
  if c in want:
   name=c[1:-1].replace('/','.');v=decode(''.join(lines));(D/(name+'.txt')).write_text(v,encoding='utf-8');print(name,len(v))
 with (S/'business_bytecode.txt').open(encoding='utf-8') as f:
  for l in f:
   if l.startswith('CLASS '):flush();c=l.strip()[6:];lines=[]
   lines.append(l)
 flush()
elif sys.argv[1]=='refs':
 pat=re.compile(sys.argv[2]);c='';m='';hits=[]
 with (S/'business_bytecode.txt').open(encoding='utf-8') as f:
  for line in f:
   if line.startswith('CLASS '):c=line.strip()[6:]
   elif line.startswith('METHOD '):m=line.strip()[7:]
   elif pat.search(line):hits.append({'class':c,'method':m,'line':line.strip()})
 (D/'last_refs.json').write_text(json.dumps(hits,ensure_ascii=False,indent=2),encoding='utf-8')
 for x in hits:print(json.dumps(x,ensure_ascii=False))
