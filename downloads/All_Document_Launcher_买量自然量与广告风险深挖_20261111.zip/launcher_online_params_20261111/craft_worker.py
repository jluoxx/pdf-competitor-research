import json,subprocess,time,hashlib
from pathlib import Path
P=Path(__file__).parent
EXE=Path('D:\\python daima\\outputs\\competitor_apk_analysis_20261109\\deep_research\\toolchain\\craft\\craft-anything-0.5.0-windows-x64-portable\\craft-anything-cli.exe')
done=set()
while not (P/'craft_stop').exists():
 for job in json.loads((P/'craft_queue.json').read_text(encoding='utf-8')):
  if (job['package']+job['id']) in done:continue
  dest=P/'raw'/job['package']/'craft';dest.mkdir(parents=True,exist_ok=True)
  meta=dest/(job['id']+'.json')
  if meta.exists():done.add(job['package']+job['id']);continue
  argfile=dest/(job['id']+'.params.json');argfile.write_text(json.dumps(job['args']),encoding='utf-8')
  cmd=[str(EXE),'--deep','--project',str(P/'craft_project.cany'),job['tool'],'@'+str(argfile)]
  start=time.time();print('START',job['id'],job['tool'],flush=True)
  try:
   result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
   (dest/(job['id']+'.stdout.json')).write_bytes(result.stdout)
   (dest/(job['id']+'.stderr.txt')).write_bytes(result.stderr)
   record={'job':job,'command':cmd,'start_epoch':start,'elapsed_seconds':time.time()-start,'returncode':result.returncode,'apk_sha256':hashlib.sha256(Path(job['args']['path']).read_bytes()).hexdigest()}
   meta.write_text(json.dumps(record,indent=2),encoding='utf-8');print('DONE',job['id'],'rc',result.returncode,flush=True)
  except Exception as e:
   meta.write_text(json.dumps({'job':job,'exception':str(e)}),encoding='utf-8');print('FAIL',job['id'],str(e),flush=True)
  done.add(job['package']+job['id'])
 break
